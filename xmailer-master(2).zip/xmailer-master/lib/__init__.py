#!/usr/bin/env python
if __name__ == "__main__":
    import banner
    import normal_mode
    import split_mode
    import combination
pass
