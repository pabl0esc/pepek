# PROJECT_NAME

Description Project 

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system.

### Fiture

* ...
* ...
* ...

### Installing

Run With PHP and Apache Server
Using XAMPP

```
http://localhost/projectfolder
```

## Built With

* [Indigo Template by Hexo](https://github.com/yscoder/hexo-theme-indigo) - Design Front End
* [PHP](/) - Server Side Back End

## Authors

* **Irfaan Programmer** - *Code Runner* - [Irfaan Programmer](https://github.com/irfaanprogrammer)

## License

This project is licensed under the MIT License