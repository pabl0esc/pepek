<?php

mysql_connect("localhost","root","") or
 die('Could not connect to the database!');


mysql_select_db("PHL") or
 die('No database selected!');
?>